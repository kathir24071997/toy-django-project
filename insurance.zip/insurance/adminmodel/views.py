
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect,get_object_or_404

# Create your views here.
from modelapp.models import RegisterModel,premiummodel,agentmodel,claimantmodel,PolicyModel
from modelapp.filters import agentfilter,claimantfilter
def base2(request):

    return render(request,'admin/base1.html')

def adminlogin(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            enter = RegisterModel.objects.get(username=username,password=password)
            return redirect('adminagent')
        except:
            pass

    return render(request, 'admin/adminlogin.html')

def agentadmin(request):
    obj = agentmodel.objects.all()
    myfilter=agentfilter(request.GET,queryset=obj)
    obj=myfilter.qs
    return render(request, 'admin/adminagent.html',{'objc':obj,'myfilter':myfilter})

def updateagent(request,pk):
    ''' user1 = ''
    username = request.session['name']'''
    objc = agentmodel.objects.get(id=pk)
    if request.method == "POST":
        fullname = request.POST.get('fullname')
        agentid = request.POST.get('agentid')
        password = request.POST.get('password')
        address = request.POST.get('address')
        mobilenumber = request.POST.get('mobilenumber')
        email = request.POST.get('email')
        gender = request.POST.get('gender')

        obj = get_object_or_404(agentmodel, id=pk)
        obj.fullname=fullname
        obj.agentid=agentid
        obj.password=password
        obj.address=address
        obj.mobilenumber=mobilenumber
        obj.email=email
        obj.gender=gender
        obj.save(update_fields=['fullname','agentid','password','address','mobilenumber','email','gender'])

        return redirect('adminagent')
    return render(request, 'admin/updateagent.html',{'obj':objc})

def policyadmin(request):
    obj = PolicyModel.objects.all()


    return render(request, 'admin/adminpolicy.html',{'objc':obj})

def claimantadmin(request):
    obj = claimantmodel.objects.all()
    myfilter = claimantfilter(request.GET, queryset=obj)
    obj = myfilter.qs
    return render(request, 'admin/adminclaimant.html',{'objc':obj,'myfilter':myfilter})
def updateclaimant(request,pk):
    ''' user1 = ''
    username = request.session['name']'''
    objc = claimantmodel.objects.get(id=pk)
    if request.method == "POST":
        fullname = request.POST.get('fullname')
        address = request.POST.get('address')
        mobilenumber = request.POST.get('mobilenumber')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        age = request.POST.get('age')


        obj = get_object_or_404(claimantmodel, id=pk)
        obj.fullname=fullname
        obj.address=address
        obj.mobilenumber=mobilenumber
        obj.email=email
        obj.gender=gender
        obj.dob=dob
        obj.age=age
        obj.save(update_fields=['fullname','address','mobilenumber','email','gender','dob','age'])

        return redirect('adminclaimant')
    return render(request, 'admin/updateclaimant.html',{'obj':objc})

def premiumadmin(request):
    obj = premiummodel.objects.all()


    return render(request, 'admin/adminpre.html',{'objc':obj})

def deleteobj(request,pk):
    obj= get_object_or_404(agentmodel,pk=pk)
    obj.delete()
    return redirect('adminagent')
def deleteobjs(request,pk):
    obj= get_object_or_404(PolicyModel,pk=pk)
    obj.delete()
    return redirect('adminpolicy')
def deleteobj1(request,pk):
    obj= get_object_or_404(claimantmodel,pk=pk)
    obj.delete()
    return redirect('adminclaimant')
def deleteobjs1(request,pk):
    obj= get_object_or_404(premiummodel,pk=pk)
    obj.delete()
    return redirect('adminpremium')