from django.apps import AppConfig


class AdminmodelConfig(AppConfig):
    name = 'adminmodel'
