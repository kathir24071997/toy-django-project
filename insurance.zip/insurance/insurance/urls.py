"""insurance URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from modelapp import views as userview
from adminmodel import views as adminview

urlpatterns = [
    url('^$',userview.home,name='home'),
    url('base/$',userview.base,name='base'),
    url('user/login/$',userview.user_login,name='login'),
    url('user/register/$',userview.registerview,name='register'),
    url('user/userinfo/$',userview.userinfo,name='userinfo'),
    url('user/addagent/$',userview.agentview,name='addagent'),
    url('user/policy/$',userview.policyview,name='policy'),
    url('user/claimant/$',userview.claimantview,name='claimant'),
    url('user/premium/$',userview.premiumview,name='premium'),


    url('admin/base1',adminview.base2,name='base'),
    url('adminlogin',adminview.adminlogin,name='adminlogin'),
    url('admin/agentdetails',adminview.agentadmin,name='adminagent'),
    url('admin/policydetails',adminview.policyadmin,name='adminpolicy'),
    url('admin/claimantdetails',adminview.claimantadmin,name='adminclaimant'),
    url('admin/premiummaturity',adminview.premiumadmin,name='adminpremium'),
    url('admin/deleteobj/(?P<pk>\d+)/$', adminview.deleteobj, name="deleteobj"),
    url('admin/deleteobjs/(?P<pk>\d+)/$', adminview.deleteobjs, name="deleteobjs"),
    url('admin/deleteobj1/(?P<pk>\d+)/$', adminview.deleteobj1, name="deleteobj1"),
    url('admin/deleteobjs1/(?P<pk>\d+)/$', adminview.deleteobjs1, name="deleteobjs1"),
    url('admin/edit/(?P<pk>\d+)/$',adminview.updateagent,name='update1'),
    url('admin/editclaimant/(?P<pk>\d+)/$',adminview.updateclaimant,name='update2'),




]
