from django.shortcuts import render,redirect
from modelapp.models import RegisterModel, agentmodel,claimantmodel,premiummodel,PolicyModel

# Create your views here.
def home(request):
    return render(request,'user/home.html')

def base(request):
    return render(request,'user/base.html')


def user_login(request):
    if request.method == "POST":
        username = request.POST.get('userid')
        password = request.POST.get('password')
        try:
            enter = RegisterModel.objects.get(username=username,password=password)
            request.session['name']=enter.id
            return redirect('userinfo')
        except:
            pass


    return render(request, 'user/login.html')

def registerview(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email =  request.POST.get('email')
        username =  request.POST.get('userid')
        password =  request.POST.get('password')
        mobilenumber =  request.POST.get('phoneno')
        gender =  request.POST.get('gender')
        RegisterModel.objects.create(name=name, emailid=email, username=username, password=password,
                                         mobilenumber=mobilenumber,gender=gender)
        return redirect('login')
    return render(request, 'user/register.html')

def userinfo(request):
    userid = request.session['name']
    ted = RegisterModel.objects.get(id=userid)
    return render(request, 'user/userinfo.html',{'objc':ted})

def agentview(request):
    user1 = ''
    username = request.session['name']
    obj = RegisterModel.objects.get(id=username)

    if request.method == "POST":
        fullname=  request.POST.get('fullname')
        agentid=  request.POST.get('agentid')
        password=  request.POST.get('password')
        address=  request.POST.get('address')
        mobilenumber =  request.POST.get('mobilenumber')
        email =  request.POST.get('email')
        gender =  request.POST.get('gender')
        agentmodel.objects.create(user1=obj,fullname=fullname,agentid=agentid,password=password,address=address,mobilenumber=mobilenumber,
                                  email=email,gender=gender)
        return redirect('addagent')
    return render(request, 'user/addagent.html')

def policyview(request):
    userDet = ''
    username = request.session['name']
    obj = RegisterModel.objects.get(id=username)

    if request.method == "POST":
        cosname=  request.POST.get('cosname')
        cosid=  request.POST.get('cosid')
        address=  request.POST.get('address')
        mobilenumber =  request.POST.get('mobilenumber')
        emailid=  request.POST.get('emailid')
        dob=  request.POST.get('dob')
        gender=  request.POST.get('gender')
        age=  request.POST.get('age')
        marital =  request.POST.get('marital')
        salary=  request.POST.get('salary')
        PolicyModel.objects.create(userDet=obj,cosid=cosid,cosname=cosname,address=address,mobilenumber=mobilenumber,
                                   emailid=emailid,dob=dob,gender=gender,age=age,marital=marital,salary=salary)
        return redirect('policy')
    return render(request, 'user/policy.html')

def claimantview(request):
    user2 = ''
    username = request.session['name']
    obj = RegisterModel.objects.get(id=username)

    if request.method == "POST":
        fullname=  request.POST.get('fullname')
        address = request.POST.get('address')
        mobilenumber = request.POST.get('mobilenumber')
        email = request.POST.get('email')
        dob = request.POST.get('dob')
        gender = request.POST.get('gender')
        age = request.POST.get('age')
        marital = request.POST.get('marital')
        claimantmodel.objects.create(user2=obj,fullname=fullname,address=address,mobilenumber=mobilenumber,
                                   email=email,dob=dob,gender=gender,age=age,marital=marital )
        return redirect('claimant')
    return render(request, 'user/claimant.html')


def premiumview(request):
    Det = ''
    username = request.session['name']
    obj = RegisterModel.objects.get(id=username)

    if request.method == "POST":
        cosname = request.POST.get('cosname')
        cosid = request.POST.get('cosid')
        policyname=  request.POST.get('policyname')
        mobilenumber = request.POST.get('mobilenumber')
        emailid = request.POST.get('emailid')
        salary=  request.POST.get('salary')
        date1=  request.POST.get('date1')
        amount1=  request.POST.get('amount1')
        date2 =  request.POST.get('date2')
        amount2 =  request.POST.get('amount2')
        date3=  request.POST.get('date3')
        amount3=  request.POST.get('amount3')
        premiummodel.objects.create(Det=obj,cosname=cosname,cosid=cosid,policyname=policyname,mobilenumber=mobilenumber,emailid=emailid,
                                     salary=salary,date1=date1,amount1=amount1,date2=date2,amount2=amount2,date3=date3,amount3=amount3)
        return redirect('premium')
    return render(request, 'user/permium.html')