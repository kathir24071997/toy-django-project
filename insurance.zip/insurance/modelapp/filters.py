import django_filters
from modelapp.models import agentmodel,claimantmodel

class agentfilter(django_filters.FilterSet):
    class Meta:
        model=agentmodel
        fields=['fullname']

class claimantfilter(django_filters.FilterSet):
    class Meta:
        model=claimantmodel
        fields=['fullname']
