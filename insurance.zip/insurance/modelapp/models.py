from django.db import models

# Create your models here.
class RegisterModel(models.Model):
    name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    mobilenumber = models.IntegerField()
    emailid = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)



class agentmodel(models.Model):
    user1 = models.ForeignKey(RegisterModel, on_delete=models.CASCADE)
    fullname = models.CharField(max_length=100)
    agentid = models.IntegerField()
    password = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    mobilenumber = models.IntegerField()
    email = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)



class PolicyModel(models.Model):
    userDet = models.ForeignKey(RegisterModel, on_delete=models.CASCADE)
    cosid = models.IntegerField()
    cosname = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    mobilenumber = models.IntegerField()
    emailid = models.EmailField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=100)
    age = models.IntegerField()
    marital = models.CharField(max_length=100)
    salary = models.IntegerField()

class claimantmodel(models.Model):
    user2 = models.ForeignKey(RegisterModel, on_delete=models.CASCADE)
    fullname = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    mobilenumber = models.IntegerField()
    email = models.EmailField()
    gender = models.CharField(max_length=100)
    dob = models.DateField()
    age = models.IntegerField()
    marital = models.CharField(max_length=100)

class premiummodel(models.Model):
    Det = models.ForeignKey(RegisterModel, on_delete=models.CASCADE)
    cosid = models.IntegerField()
    cosname = models.CharField(max_length=100)
    policyname = models.CharField(max_length=100)
    mobilenumber = models.IntegerField()
    emailid = models.EmailField(max_length=100)
    salary = models.IntegerField()
    date1 = models.DateField()
    amount1 = models.IntegerField()
    date2 = models.DateField()
    amount2 = models.IntegerField()
    date3 = models.DateField()
    amount3 = models.IntegerField()