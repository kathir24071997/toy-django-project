from django.apps import AppConfig


class ModelappConfig(AppConfig):
    name = 'modelapp'
